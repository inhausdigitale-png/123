const STORAGE_KEY = "campaign-log-web-app-v1";

const platformOptions = ["Meta", "Google", "YouTube", "LinkedIn", "TikTok", "Email", "Other"];
const statusOptions = ["Active", "Learning", "Needs Action", "Paused", "Scaled", "Testing", "Completed", "On Hold"];
const changeTypes = [
  "Image / Creative",
  "Audience / Targeting",
  "Budget",
  "Bid / Optimization",
  "Landing Page",
  "Copy / CTA",
  "Placement",
  "Schedule",
  "Other",
];
const owners = ["Marketing", "Creative", "Performance", "Sales", "Client"];
const nextActions = ["No Change", "Monitor", "Improve Creative", "Change Targeting", "Reduce Budget", "Scale", "Pause"];
const defaultMetrics = [
  { name: "CPA/CPL", direction: "lower" },
  { name: "ROAS", direction: "higher" },
  { name: "CTR", direction: "higher" },
  { name: "CVR", direction: "higher" },
  { name: "Leads", direction: "higher" },
  { name: "SVC", direction: "higher" },
  { name: "SVC %", direction: "higher" },
  { name: "Booked", direction: "higher" },
  { name: "Booked %", direction: "higher" },
];
const defaultTrackerColumnIds = [
  "date", "project", "id", "name", "platform", "objective", "status", "lastEdited", "lastChange",
  "metric", "before", "after", "budget", "spend", "impressions", "clicks", "leads", "svc", "booked",
  "revenue", "ctr", "cvr", "svcRate", "bookedRate", "cpa", "roas", "flag", "performance",
];
const importTemplates = {
  campaigns: [
    "Date", "Project", "Ad Account ID", "Campaign ID", "Name", "Platform", "Placement", "Country", "Age", "Device", "Objective", "Budget",
    "Metric", "Before Value", "After Value", "Spend", "Impressions", "Clicks", "Leads", "SVC", "Booked", "Revenue",
  ],
  changes: [
    "Change ID", "Date", "Project", "Ad Account ID", "Campaign ID", "Campaign Status", "Type", "Changed", "Reason", "Metric",
    "Before Value", "After Value", "Leads", "SVC", "Booked", "Owner", "Follow-up", "Next Action",
  ],
  projects: ["Project", "Ad Account ID"],
  metrics: ["Metric", "Improvement Direction"],
};

const sampleState = {
  filters: {
    project: "All Projects",
    startDate: "",
    endDate: "",
  },
  trackerColumns: structuredClone(defaultTrackerColumnIds),
  projects: [
    { name: "Main Project", adAccountId: "" },
    { name: "Audience Test", adAccountId: "" },
  ],
  metrics: structuredClone(defaultMetrics),
  settings: {
    targetCpa: 500,
    minRoas: 2.5,
    minCtr: 1.5,
    minCvr: 2,
    reviewDays: 3,
    warningSpend: 1000,
  },
  campaigns: [
    {
      date: "2026-06-01",
      project: "Main Project",
      id: "CMP-001",
      name: "Summer Lead Gen",
      platform: "Meta",
      placement: "Feed",
      country: "India",
      age: "25-34",
      device: "Mobile",
      objective: "Leads",
      status: "Active",
      metric: "CPA/CPL",
      before: 75,
      after: 61.76,
      budget: 5000,
      spend: 4200,
      impressions: 88000,
      clicks: 1320,
      leads: 68,
      svc: 24,
      booked: 8,
      revenue: 0,
    },
    {
      date: "2026-06-01",
      project: "Main Project",
      id: "CMP-002",
      name: "Retargeting Sales",
      platform: "Google",
      placement: "Search",
      country: "India",
      age: "35-44",
      device: "Desktop",
      objective: "Sales",
      status: "Active",
      metric: "ROAS",
      before: 2.8,
      after: 3.23,
      budget: 7000,
      spend: 6500,
      impressions: 55000,
      clicks: 2100,
      leads: 120,
      svc: 45,
      booked: 18,
      revenue: 21000,
    },
    {
      date: "2026-06-01",
      project: "Audience Test",
      id: "CMP-003",
      name: "New Audience Test",
      platform: "Meta",
      placement: "Stories",
      country: "India",
      age: "18-24",
      device: "Mobile",
      objective: "Leads",
      status: "Learning",
      metric: "CPA/CPL",
      before: 220,
      after: 175,
      budget: 3000,
      spend: 1400,
      impressions: 61000,
      clicks: 430,
      leads: 8,
      svc: 2,
      booked: 0,
      revenue: 0,
    },
  ],
  changes: [
    {
      id: "CHG-001",
      date: "2026-06-02",
      campaignId: "CMP-003",
      campaignStatus: "Needs Action",
      type: "Image / Creative",
      changed: "Changed main image to product-use image",
      reason: "Low CTR and high CPL",
      metric: "CPA/CPL",
      before: 175,
      after: 120,
      leads: 8,
      svc: 2,
      booked: 0,
      owner: "Creative",
      followUp: "2026-06-05",
      nextAction: "Monitor",
    },
    {
      id: "CHG-002",
      date: "2026-06-02",
      campaignId: "CMP-001",
      campaignStatus: "Active",
      type: "Audience / Targeting",
      changed: "Excluded low-quality age group",
      reason: "Leads not converting",
      metric: "CPA/CPL",
      before: 62,
      after: 0,
      leads: 68,
      svc: 24,
      booked: 8,
      owner: "Performance",
      followUp: "2026-06-05",
      nextAction: "Monitor",
    },
  ],
};

let state = loadState();
let saveStatusTimer;

function loadState() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (!saved) return structuredClone(sampleState);
  try {
    return normalizeState({ ...structuredClone(sampleState), ...JSON.parse(saved) });
  } catch {
    return structuredClone(sampleState);
  }
}

function normalizeState(nextState) {
  nextState.filters = {
    project: nextState.filters?.project || "All Projects",
    startDate: nextState.filters?.startDate || "",
    endDate: nextState.filters?.endDate || "",
  };
  nextState.trackerColumns = Array.isArray(nextState.trackerColumns) && nextState.trackerColumns.length
    ? nextState.trackerColumns.filter((id) => defaultTrackerColumnIds.includes(id) || id.startsWith("metric:"))
    : structuredClone(defaultTrackerColumnIds);
  nextState.campaigns = (nextState.campaigns || []).map((row) => ({
    ...row,
    project: row.project || "Main Project",
    placement: row.placement || "",
    country: row.country || "",
    age: row.age || "",
    device: row.device || "",
    metric: row.metric || "CPA/CPL",
    before: numberValue(row.before),
    after: numberValue(row.after),
    leads: numberValue(row.leads ?? row.conversions),
    svc: numberValue(row.svc),
    booked: numberValue(row.booked),
  }));
  nextState.changes = (nextState.changes || []).map((row) => ({
    ...row,
    project: row.project || nextState.campaigns.find((campaign) => campaign.id === row.campaignId)?.project || "Main Project",
    campaignStatus: row.campaignStatus || nextState.campaigns.find((campaign) => campaign.id === row.campaignId)?.status || "Active",
    metric: row.metric || "CPA/CPL",
    leads: numberValue(row.leads),
    svc: numberValue(row.svc),
    booked: numberValue(row.booked),
  }));
  const projectNames = new Set([
    ...(nextState.projects || []).map((project) => project.name).filter(Boolean),
    ...nextState.campaigns.map((row) => row.project).filter(Boolean),
    ...nextState.changes.map((row) => row.project).filter(Boolean),
  ]);
  const existingProjects = new Map((nextState.projects || []).map((project) => [project.name, project]));
  nextState.projects = [...projectNames].map((name) => ({
    name,
    adAccountId: existingProjects.get(name)?.adAccountId || "",
  }));
  nextState.metrics = (nextState.metrics?.length ? nextState.metrics : structuredClone(defaultMetrics))
    .filter((metric) => metric.name)
    .map((metric) => ({
      name: metric.name,
      direction: metric.direction === "lower" ? "lower" : "higher",
    }));
  return nextState;
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  showSaveStatus("Saved");
}

function showSaveStatus(message) {
  const status = document.querySelector("#saveStatus");
  if (!status) return;
  status.textContent = message;
  clearTimeout(saveStatusTimer);
  saveStatusTimer = setTimeout(() => {
    status.textContent = "Saved";
  }, 1600);
}

function money(value) {
  return Number(value || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 });
}

function percent(value) {
  if (!Number.isFinite(value)) return "";
  return `${(value * 100).toFixed(2)}%`;
}

function numberValue(value) {
  const next = Number(value);
  return Number.isFinite(next) ? next : 0;
}

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function addDays(dateString, days) {
  const base = dateString ? new Date(`${dateString}T00:00:00`) : new Date();
  base.setDate(base.getDate() + Number(days || 0));
  return base.toISOString().slice(0, 10);
}

function inDateRange(dateString) {
  const start = state.filters?.startDate;
  const end = state.filters?.endDate;
  if (!start && !end) return true;
  if (!dateString) return false;
  if (start && dateString < start) return false;
  if (end && dateString > end) return false;
  return true;
}

function matchesProject(row) {
  const project = state.filters?.project || "All Projects";
  const rowProject = row.project || campaignProject(row.campaignId);
  return project === "All Projects" || rowProject === project;
}

function campaignName(campaignId) {
  return state.campaigns.find((campaign) => campaign.id === campaignId)?.name || "";
}

function campaignProject(campaignId) {
  return state.campaigns.find((campaign) => campaign.id === campaignId)?.project || "";
}

function latestChangeDate(campaignId) {
  return state.changes
    .filter((row) => row.campaignId === campaignId && row.date)
    .map((row) => row.date)
    .sort()
    .at(-1) || "";
}

function latestChangeText(campaignId) {
  const latest = state.changes
    .filter((row) => row.campaignId === campaignId && row.date)
    .sort((a, b) => a.date.localeCompare(b.date))
    .at(-1);
  return latest?.changed || "";
}

function latestCampaignStatus(campaignId, fallback = "Active") {
  const latest = state.changes
    .filter((row) => row.campaignId === campaignId && row.date && row.campaignStatus)
    .sort((a, b) => a.date.localeCompare(b.date))
    .at(-1);
  return latest?.campaignStatus || fallback || "Active";
}

function calcCampaign(row) {
  const leads = numberValue(row.leads ?? row.conversions);
  const svc = numberValue(row.svc);
  const booked = numberValue(row.booked);
  const ctr = row.impressions ? row.clicks / row.impressions : 0;
  const cvr = row.clicks ? leads / row.clicks : 0;
  const svcRate = leads ? svc / leads : 0;
  const bookedRate = svc ? booked / svc : 0;
  const cpa = leads ? row.spend / leads : row.spend || 0;
  const roas = row.spend ? row.revenue / row.spend : 0;
  const needsFix = leads === 0 && row.spend >= state.settings.warningSpend;
  const needsAction =
    cpa > state.settings.targetCpa ||
    ctr < state.settings.minCtr / 100 ||
    cvr < state.settings.minCvr / 100 ||
    roas < state.settings.minRoas;
  const flag = needsFix ? "Pause / Fix" : needsAction ? "Needs Action" : "Good";
  const performance = performanceIndicator({ ...row, flag });
  return { leads, svc, booked, ctr, cvr, svcRate, bookedRate, cpa, roas, flag, performance };
}

function performanceIndicator(row) {
  if (row.flag === "Pause / Fix") return "Critical";
  const before = numberValue(row.before);
  const after = numberValue(row.after);
  if (!before && !after) return row.flag === "Good" ? "Good" : "Watch";
  if (!after) return "Waiting";
  const lowerIsBetter = metricDirection(row.metric || "CPA/CPL") === "lower";
  const improved = lowerIsBetter ? after < before : after > before;
  if (improved && row.flag === "Good") return "Improving";
  if (improved) return "Recovering";
  if (!improved && row.flag === "Good") return "Stable";
  return "Declining";
}

function calcChange(row) {
  if (!row.before && !row.after) return "Waiting";
  if (!row.after) return "Waiting";
  const before = numberValue(row.before);
  const after = numberValue(row.after);
  const lowerIsBetter = metricDirection(row.metric || "CPA/CPL") === "lower";
  return lowerIsBetter ? (after < before ? "Yes" : "No") : (after > before ? "Yes" : "No");
}

function calcChangeFunnel(row) {
  const leads = numberValue(row.leads);
  const svc = numberValue(row.svc);
  const booked = numberValue(row.booked);
  return {
    leads,
    svc,
    booked,
    svcRate: leads ? svc / leads : 0,
    bookedRate: svc ? booked / svc : 0,
  };
}

function reviewStatus(row) {
  const due = row.followUp && new Date(`${row.followUp}T00:00:00`) <= new Date(`${todayIso()}T00:00:00`);
  return due ? "Review Due" : "Pending Review";
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function input(value, type, onInput) {
  const node = document.createElement("input");
  node.type = type;
  node.value = value ?? "";
  node.addEventListener("change", (event) => onInput(event.target.value));
  return node;
}

function textarea(value, onInput) {
  const node = document.createElement("textarea");
  node.value = value ?? "";
  node.addEventListener("change", (event) => onInput(event.target.value));
  return node;
}

function select(value, options, onChange) {
  const node = document.createElement("select");
  options.forEach((option) => {
    const item = document.createElement("option");
    item.value = option;
    item.textContent = option;
    node.append(item);
  });
  node.value = value || options[0];
  node.addEventListener("change", (event) => onChange(event.target.value));
  return node;
}

function td(child, className = "") {
  const cell = document.createElement("td");
  if (className) cell.className = className;
  if (child instanceof Node) cell.append(child);
  else cell.textContent = child ?? "";
  return cell;
}

function updateCampaign(index, key, value) {
  const numeric = ["before", "after", "budget", "spend", "impressions", "clicks", "leads", "svc", "booked", "revenue"];
  state.campaigns[index][key] = numeric.includes(key) ? numberValue(value) : value;
  saveState();
  render();
}

function updateChange(index, key, value) {
  const numeric = ["before", "after", "leads", "svc", "booked"];
  state.changes[index][key] = numeric.includes(key) ? numberValue(value) : value;
  if (key === "campaignId" && !state.changes[index].project) {
    state.changes[index].project = campaignProject(value);
  }
  if (key === "date" && !state.changes[index].followUp) {
    state.changes[index].followUp = addDays(value, state.settings.reviewDays);
  }
  saveState();
  render();
}

function trackerColumnDefinitions(row, index, calc) {
  const baseMetricNames = new Set(["CPA/CPL", "ROAS", "CTR", "CVR", "Leads", "SVC", "SVC %", "Booked", "Booked %"]);
  return [
    { id: "date", label: "Date", cell: () => td(input(row.date, "date", (value) => updateCampaign(index, "date", value))) },
    { id: "project", label: "Project", cell: () => td(select(row.project, projectOptions(), (value) => updateCampaign(index, "project", value)), "wide") },
    { id: "id", label: "Campaign ID", cell: () => td(input(row.id, "text", (value) => updateCampaign(index, "id", value))) },
    { id: "name", label: "Name", cell: () => td(input(row.name, "text", (value) => updateCampaign(index, "name", value)), "wide") },
    { id: "platform", label: "Platform", cell: () => td(select(row.platform, platformOptions, (value) => updateCampaign(index, "platform", value))) },
    { id: "objective", label: "Objective", cell: () => td(input(row.objective, "text", (value) => updateCampaign(index, "objective", value))) },
    { id: "status", label: "Status", cell: () => td(latestCampaignStatus(row.id, row.status), "calc-cell") },
    { id: "lastEdited", label: "Last Edited", cell: () => td(latestChangeDate(row.id) || "-", "calc-cell") },
    { id: "lastChange", label: "Last Change", cell: () => td(latestChangeText(row.id) || "-", "calc-cell wide") },
    { id: "metric", label: "Metric", cell: () => td(row.metric || "CPA/CPL", "calc-cell") },
    { id: "before", label: "Before Value", cell: () => td(money(row.before), "calc-cell") },
    { id: "after", label: "After Value", cell: () => td(money(row.after), "calc-cell") },
    { id: "budget", label: "Budget", cell: () => td(money(row.budget), "calc-cell") },
    { id: "spend", label: "Spend", cell: () => td(money(row.spend), "calc-cell") },
    { id: "impressions", label: "Impressions", cell: () => td(money(row.impressions), "calc-cell") },
    { id: "clicks", label: "Clicks", cell: () => td(money(row.clicks), "calc-cell") },
    { id: "leads", label: "Leads", cell: () => td(money(calc.leads), "calc-cell") },
    { id: "svc", label: "SVC", cell: () => td(money(calc.svc), "calc-cell") },
    { id: "booked", label: "Booked", cell: () => td(money(calc.booked), "calc-cell") },
    { id: "revenue", label: "Revenue", cell: () => td(money(row.revenue), "calc-cell") },
    { id: "ctr", label: "CTR", cell: () => td(percent(calc.ctr), "calc-cell") },
    { id: "cvr", label: "CVR", cell: () => td(percent(calc.cvr), "calc-cell") },
    { id: "svcRate", label: "SVC %", cell: () => td(percent(calc.svcRate), "calc-cell") },
    { id: "bookedRate", label: "Booked %", cell: () => td(percent(calc.bookedRate), "calc-cell") },
    { id: "cpa", label: "CPA/CPL", cell: () => td(money(calc.cpa), "calc-cell") },
    { id: "roas", label: "ROAS", cell: () => td(calc.roas.toFixed(2), "calc-cell") },
    { id: "flag", label: "Flag", cell: () => td(calc.flag, `calc-cell ${flagClass(calc.flag)}`) },
    { id: "performance", label: "Performance", cell: () => td(calc.performance, `calc-cell ${performanceClass(calc.performance)}`) },
    ...metricOptions().filter((metricName) => !baseMetricNames.has(metricName)).map((metricName) => ({
      id: `metric:${metricName}`,
      label: metricName,
      cell: () => td(metricDisplayValue(metricName, row, calc), "calc-cell"),
    })),
  ];
}

function metricDisplayValue(metricName, row, calc) {
  const map = {
    "CPA/CPL": money(calc.cpa),
    ROAS: calc.roas.toFixed(2),
    CTR: percent(calc.ctr),
    CVR: percent(calc.cvr),
    Leads: money(calc.leads),
    SVC: money(calc.svc),
    "SVC %": percent(calc.svcRate),
    Booked: money(calc.booked),
    "Booked %": percent(calc.bookedRate),
  };
  if (map[metricName] !== undefined) return map[metricName];
  return row.metric === metricName ? money(row.after || row.before) : "";
}

function visibleTrackerColumns(row, index, calc) {
  const selected = new Set(state.trackerColumns || defaultTrackerColumnIds);
  return trackerColumnDefinitions(row, index, calc).filter((column) => selected.has(column.id));
}

function renderCampaignRows() {
  renderCampaignHeaders();
  const body = document.querySelector("#campaignRows");
  body.innerHTML = "";
  state.campaigns.forEach((row, index) => {
    const calc = calcCampaign(row);
    const tr = document.createElement("tr");
    tr.append(...visibleTrackerColumns(row, index, calc).map((column) => column.cell()));
    tr.append(td(deleteButton(() => {
      state.campaigns.splice(index, 1);
      saveState();
      render();
    })));
    body.append(tr);
  });
}

function renderCampaignHeaders() {
  const row = document.querySelector("#campaignHeaderRow");
  if (!row) return;
  const sample = state.campaigns[0] || {};
  const headers = visibleTrackerColumns(sample, 0, calcCampaign(sample)).map((column) => column.label);
  row.innerHTML = headers.map((label) => `<th>${label}</th>`).join("") + "<th></th>";
}

function renderChangeRows() {
  const body = document.querySelector("#changeRows");
  body.innerHTML = "";
  state.changes.forEach((row, index) => {
    const improved = calcChange(row);
    const funnel = calcChangeFunnel(row);
    const tr = document.createElement("tr");
    tr.append(
      td(input(row.id, "text", (value) => updateChange(index, "id", value))),
      td(input(row.date, "date", (value) => updateChange(index, "date", value))),
      td(select(row.project || campaignProject(row.campaignId), projectOptions(), (value) => updateChange(index, "project", value)), "wide"),
      td(select(row.campaignId, campaignOptions(), (value) => updateChange(index, "campaignId", value))),
      td(select(row.campaignStatus || latestCampaignStatus(row.campaignId), statusOptions, (value) => updateChange(index, "campaignStatus", value))),
      td(select(row.type, changeTypes, (value) => updateChange(index, "type", value))),
      td(textarea(row.changed, (value) => updateChange(index, "changed", value)), "wide"),
      td(textarea(row.reason, (value) => updateChange(index, "reason", value)), "wide"),
      td(select(row.metric || "CPA/CPL", metricOptions(), (value) => updateChange(index, "metric", value))),
      td(input(row.before, "number", (value) => updateChange(index, "before", value)), "number-cell"),
      td(input(row.after, "number", (value) => updateChange(index, "after", value)), "number-cell"),
      td(improved, `calc-cell ${changeClass(improved)}`),
      td(input(funnel.leads, "number", (value) => updateChange(index, "leads", value)), "number-cell"),
      td(input(funnel.svc, "number", (value) => updateChange(index, "svc", value)), "number-cell"),
      td(percent(funnel.svcRate), "calc-cell"),
      td(input(funnel.booked, "number", (value) => updateChange(index, "booked", value)), "number-cell"),
      td(percent(funnel.bookedRate), "calc-cell"),
      td(select(row.owner, owners, (value) => updateChange(index, "owner", value))),
      td(input(row.followUp, "date", (value) => updateChange(index, "followUp", value))),
      td(reviewStatus(row), `calc-cell ${reviewStatus(row) === "Review Due" ? "flag-danger" : "flag-waiting"}`),
      td(select(row.nextAction, nextActions, (value) => updateChange(index, "nextAction", value))),
      td(deleteButton(() => {
        state.changes.splice(index, 1);
        saveState();
        render();
      })),
    );
    body.append(tr);
  });
}

function campaignOptions() {
  const ids = state.campaigns.map((row) => row.id).filter(Boolean);
  return ids.length ? ids : ["No Campaign"];
}

function projectOptions() {
  const names = [
    ...state.projects.map((project) => project.name).filter(Boolean),
    ...state.campaigns.map((row) => row.project).filter(Boolean),
  ];
  const unique = [...new Set(names)];
  return unique.length ? unique : ["Main Project"];
}

function adAccountForProject(projectName) {
  return state.projects.find((project) => project.name === projectName)?.adAccountId || "";
}

function metricOptions() {
  const names = state.metrics.map((metric) => metric.name).filter(Boolean);
  return names.length ? names : defaultMetrics.map((metric) => metric.name);
}

function metricDirection(metricName) {
  return state.metrics.find((metric) => metric.name === metricName)?.direction || "higher";
}

function deleteButton(onClick) {
  const button = el("button", "icon-button", "x");
  button.type = "button";
  button.title = "Delete row";
  button.addEventListener("click", onClick);
  return button;
}

function flagClass(flag) {
  if (flag === "Good") return "flag-good";
  if (flag === "Pause / Fix") return "flag-danger";
  return "flag-warning";
}

function changeClass(value) {
  if (value === "Yes") return "flag-improved";
  if (value === "No") return "flag-not";
  return "flag-waiting";
}

function performanceClass(value) {
  if (["Good", "Improving", "Recovering", "Stable"].includes(value)) return "flag-good";
  if (["Critical", "Declining"].includes(value)) return "flag-danger";
  return "flag-warning";
}

function renderDashboard() {
  const dateCampaignRows = state.campaigns.filter((row) => inDateRange(row.date));
  const dateChangeRows = state.changes.filter((row) => inDateRange(row.date));
  const campaignRows = dateCampaignRows.filter(matchesProject);
  const changeRows = dateChangeRows.filter(matchesProject);
  const totals = campaignRows.reduce(
    (acc, row) => {
      const calc = calcCampaign(row);
      acc.spend += numberValue(row.spend);
      acc.leads += calc.leads;
      acc.svc += calc.svc;
      acc.booked += calc.booked;
      acc.needsAction += calc.flag === "Needs Action" || calc.flag === "Pause / Fix" ? 1 : 0;
      acc.good += calc.flag === "Good" ? 1 : 0;
      acc.warning += calc.flag === "Needs Action" ? 1 : 0;
      acc.danger += calc.flag === "Pause / Fix" ? 1 : 0;
      acc.performance[calc.performance] = (acc.performance[calc.performance] || 0) + 1;
      return acc;
    },
    { spend: 0, leads: 0, svc: 0, booked: 0, needsAction: 0, good: 0, warning: 0, danger: 0, performance: {} },
  );
  const due = changeRows.filter((row) => reviewStatus(row) === "Review Due").length;
  const avgCpa = totals.leads ? totals.spend / totals.leads : 0;
  const svcRate = totals.leads ? totals.svc / totals.leads : 0;
  const bookedRate = totals.svc ? totals.booked / totals.svc : 0;
  const projectCount = new Set(campaignRows.map((row) => row.project).filter(Boolean)).size;

  const metrics = [
    ["Projects", projectCount],
    ["Campaign Rows", campaignRows.length],
    ["Total Spend", money(totals.spend)],
    ["Leads", money(totals.leads)],
    ["SVC", money(totals.svc)],
    ["Booked", money(totals.booked)],
    ["SVC %", percent(svcRate)],
    ["Booked %", percent(bookedRate)],
    ["Avg CPA / CPL", money(avgCpa)],
    ["Need Action", totals.needsAction],
    ["Reviews Due", due],
  ];
  document.querySelector("#metricGrid").innerHTML = metrics
    .map((item) => `<article class="metric"><span>${item[0]}</span><strong>${item[1]}</strong></article>`)
    .join("");

  renderBars("#decisionBars", [
    ["Good", totals.good, "var(--green)"],
    ["Needs Action", totals.warning, "var(--amber)"],
    ["Pause / Fix", totals.danger, "var(--red)"],
  ]);

  const results = changeRows.reduce(
    (acc, row) => {
      acc[calcChange(row)] += 1;
      return acc;
    },
    { Yes: 0, No: 0, Waiting: 0 },
  );
  renderBars("#resultList", [
    ["Improving", (totals.performance.Improving || 0) + (totals.performance.Recovering || 0), "var(--green)"],
    ["Stable / Good", (totals.performance.Stable || 0) + (totals.performance.Good || 0), "var(--teal)"],
    ["Declining", totals.performance.Declining || 0, "var(--red)"],
    ["Critical", totals.performance.Critical || 0, "var(--red)"],
    ["Waiting / Watch", (totals.performance.Waiting || 0) + (totals.performance.Watch || 0), "var(--amber)"],
  ]);
  renderProjectSummary(dateCampaignRows);
}

function renderProjectSummary(rows) {
  const grouped = new Map();
  rows.forEach((row) => {
    const project = row.project || "Main Project";
    if (!grouped.has(project)) {
      grouped.set(project, { project, rows: 0, spend: 0, leads: 0, svc: 0, booked: 0, needsAction: 0, indicators: {} });
    }
    const item = grouped.get(project);
    const calc = calcCampaign(row);
    item.rows += 1;
    item.spend += numberValue(row.spend);
    item.leads += calc.leads;
    item.svc += calc.svc;
    item.booked += calc.booked;
    item.needsAction += calc.flag === "Needs Action" || calc.flag === "Pause / Fix" ? 1 : 0;
    item.indicators[calc.performance] = (item.indicators[calc.performance] || 0) + 1;
  });

  const tbody = document.querySelector("#projectSummaryRows");
  const items = [...grouped.values()].sort((a, b) => a.project.localeCompare(b.project));
  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="11">No project data in this date range.</td></tr>`;
    return;
  }
  tbody.innerHTML = items
    .map((item) => {
      const svcRate = item.leads ? item.svc / item.leads : 0;
      const bookedRate = item.svc ? item.booked / item.svc : 0;
      const mainIndicator = mainProjectIndicator(item.indicators);
      return `
        <tr>
          <td>${item.project}</td>
          <td>${adAccountForProject(item.project)}</td>
          <td class="number-cell">${item.rows}</td>
          <td class="number-cell">${money(item.spend)}</td>
          <td class="number-cell">${money(item.leads)}</td>
          <td class="number-cell">${money(item.svc)}</td>
          <td class="number-cell">${percent(svcRate)}</td>
          <td class="number-cell">${money(item.booked)}</td>
          <td class="number-cell">${percent(bookedRate)}</td>
          <td class="number-cell">${item.needsAction}</td>
          <td class="${performanceClass(mainIndicator)}">${mainIndicator}</td>
        </tr>
      `;
    })
    .join("");
}

function mainProjectIndicator(indicators) {
  const priority = ["Critical", "Declining", "Watch", "Waiting", "Recovering", "Improving", "Stable", "Good"];
  return priority.find((item) => indicators[item]) || "Good";
}

function renderBars(selector, rows) {
  const max = Math.max(1, ...rows.map((row) => row[1]));
  document.querySelector(selector).innerHTML = rows
    .map(
      ([label, count, color]) => `
        <div class="summary-row">
          <strong>${label}</strong>
          <div class="bar-track"><div class="bar-fill" style="width:${(count / max) * 100}%; background:${color}"></div></div>
          <span>${count}</span>
        </div>
      `,
    )
    .join("");
}

function renderReviews() {
  const list = document.querySelector("#reviewList");
  const rows = state.changes
    .filter((row) => row.followUp)
    .sort((a, b) => a.followUp.localeCompare(b.followUp));
  document.querySelector("#reviewCount").textContent = `${rows.length} scheduled`;

  if (!rows.length) {
    list.innerHTML = document.querySelector("#emptyState").innerHTML;
    return;
  }

  list.innerHTML = rows
    .map((row) => {
      const due = reviewStatus(row) === "Review Due";
      return `
        <article class="review-card ${due ? "is-due" : ""}">
          <div>
            <strong>${row.project || campaignProject(row.campaignId)} - ${row.id}</strong>
            <span>${campaignName(row.campaignId) || row.campaignId}</span>
            <span>${row.type} - ${row.changed || "No change detail entered"}</span>
          </div>
          <span class="status-pill ${due ? "flag-danger" : "flag-waiting"}">${reviewStatus(row)} - ${row.followUp}</span>
        </article>
      `;
    })
    .join("");
}

function renderSettings() {
  Object.entries(state.settings).forEach(([key, value]) => {
    const field = document.querySelector(`#${key}`);
    if (field && document.activeElement !== field) field.value = value;
  });
  renderProjectSettings();
  renderMetricSettings();
  renderTrackerColumnSettings();
  renderTrackerToolbarMenus();
}

function updateProjectSetting(index, key, value) {
  const oldName = state.projects[index]?.name;
  state.projects[index][key] = value;
  if (key === "name" && oldName && value) {
    state.campaigns.forEach((row) => {
      if (row.project === oldName) row.project = value;
    });
    state.changes.forEach((row) => {
      if (row.project === oldName) row.project = value;
    });
    if (state.filters.project === oldName) state.filters.project = value;
  }
  saveState();
  render();
}

function renderProjectSettings() {
  const body = document.querySelector("#projectSettingRows");
  if (!body) return;
  body.innerHTML = "";
  state.projects.forEach((project, index) => {
    const tr = document.createElement("tr");
    tr.append(
      td(input(project.name, "text", (value) => updateProjectSetting(index, "name", value)), "wide"),
      td(input(project.adAccountId, "text", (value) => updateProjectSetting(index, "adAccountId", value)), "wide"),
      td(deleteButton(() => {
        if (state.projects.length <= 1) return;
        state.projects.splice(index, 1);
        saveState();
        render();
      })),
    );
    body.append(tr);
  });
}

function updateMetricSetting(index, key, value) {
  const oldName = state.metrics[index]?.name;
  state.metrics[index][key] = value;
  if (key === "name" && oldName && value) {
    state.campaigns.forEach((row) => {
      if (row.metric === oldName) row.metric = value;
    });
    state.changes.forEach((row) => {
      if (row.metric === oldName) row.metric = value;
    });
  }
  saveState();
  render();
}

function renderMetricSettings() {
  const body = document.querySelector("#metricSettingRows");
  if (!body) return;
  body.innerHTML = "";
  state.metrics.forEach((metric, index) => {
    const tr = document.createElement("tr");
    tr.append(
      td(input(metric.name, "text", (value) => updateMetricSetting(index, "name", value)), "wide"),
      td(select(metric.direction || "higher", ["higher", "lower"], (value) => updateMetricSetting(index, "direction", value))),
      td(deleteButton(() => {
        if (state.metrics.length <= 1) return;
        const removed = state.metrics[index].name;
        state.metrics.splice(index, 1);
        const fallback = metricOptions()[0] || "CPA/CPL";
        state.campaigns.forEach((row) => {
          if (row.metric === removed) row.metric = fallback;
        });
        state.changes.forEach((row) => {
          if (row.metric === removed) row.metric = fallback;
        });
        saveState();
        render();
      })),
    );
    body.append(tr);
  });
}

function renderTrackerColumnSettings() {
  const container = document.querySelector("#trackerColumnSettings");
  if (!container) return;
  renderColumnCheckboxes(container, "tracker");
}

function renderTrackerToolbarMenus() {
  const columnMenu = document.querySelector("#trackerColumnMenu");
  if (columnMenu) renderColumnCheckboxes(columnMenu, "tracker");
}

function renderColumnCheckboxes(container, mode) {
  const sample = state.campaigns[0] || {};
  const columns = trackerColumnDefinitions(sample, 0, calcCampaign(sample));
  const selected = new Set(state.trackerColumns || defaultTrackerColumnIds);
  container.innerHTML = "";
  columns.forEach((column) => {
    const label = document.createElement("label");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = selected.has(column.id);
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) {
        state.trackerColumns = [...new Set([...(state.trackerColumns || []), column.id])];
      } else {
        state.trackerColumns = (state.trackerColumns || []).filter((id) => id !== column.id);
      }
      saveState();
      render();
    });
    label.append(checkbox, column.label);
    container.append(label);
  });
}

function renderFilters() {
  const start = document.querySelector("#filterStart");
  const end = document.querySelector("#filterEnd");
  const project = document.querySelector("#filterProject");
  if (project) {
    const current = state.filters?.project || "All Projects";
    const projects = ["All Projects", ...projectOptions()];
    project.innerHTML = projects.map((item) => `<option value="${item}">${item}</option>`).join("");
    project.value = projects.includes(current) ? current : "All Projects";
  }
  if (start && document.activeElement !== start) start.value = state.filters?.startDate || "";
  if (end && document.activeElement !== end) end.value = state.filters?.endDate || "";
}

function render() {
  document.querySelector("#todayChip").textContent = new Date().toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
  renderCampaignRows();
  renderChangeRows();
  renderDashboard();
  renderReviews();
  renderSettings();
  renderFilters();
}

function addCampaign() {
  const next = String(state.campaigns.length + 1).padStart(3, "0");
  state.campaigns.push({
    date: todayIso(),
    project: "Main Project",
    id: `CMP-${next}`,
    name: "",
    platform: "Meta",
    placement: "",
    country: "",
    age: "",
    device: "",
    objective: "Leads",
    status: "Testing",
    metric: "CPA/CPL",
    before: 0,
    after: 0,
    budget: 0,
    spend: 0,
    impressions: 0,
    clicks: 0,
    leads: 0,
    svc: 0,
    booked: 0,
    revenue: 0,
  });
  saveState();
  render();
}

function addChange() {
  const next = String(state.changes.length + 1).padStart(3, "0");
  const campaignId = state.campaigns[0]?.id || "CMP-001";
  state.changes.push({
    id: `CHG-${next}`,
    date: todayIso(),
    campaignId,
    project: campaignProject(campaignId) || "Main Project",
    campaignStatus: latestCampaignStatus(campaignId, "Active"),
    type: "Image / Creative",
    changed: "",
    reason: "",
    metric: "CPA/CPL",
    before: 0,
    after: 0,
    leads: 0,
    svc: 0,
    booked: 0,
    owner: "Performance",
    followUp: addDays(todayIso(), state.settings.reviewDays),
    nextAction: "Monitor",
  });
  saveState();
  render();
}

function bindEvents() {
  document.querySelectorAll(".tab").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((tab) => tab.classList.remove("is-active"));
      document.querySelectorAll(".panel").forEach((panel) => panel.classList.remove("is-active"));
      button.classList.add("is-active");
      document.querySelector(`#${button.dataset.tab}`).classList.add("is-active");
    });
  });

  document.querySelector("#addCampaign").addEventListener("click", addCampaign);
  document.querySelector("#addChange").addEventListener("click", addChange);
  document.querySelector("#saveData").addEventListener("click", () => {
    saveState();
    showSaveStatus("Saved now");
  });
  document.querySelector("#addProjectSetting").addEventListener("click", () => {
    const next = state.projects.length + 1;
    state.projects.push({ name: `Project ${next}`, adAccountId: "" });
    saveState();
    render();
  });
  document.querySelector("#addMetricSetting").addEventListener("click", () => {
    const next = state.metrics.length + 1;
    state.metrics.push({ name: `Metric ${next}`, direction: "higher" });
    saveState();
    render();
  });
  document.querySelector("#downloadTemplate").addEventListener("click", downloadImportTemplate);
  document.querySelector("#importFile").addEventListener("change", importCsvFile);
  document.querySelector("#filterProject").addEventListener("change", (event) => {
    state.filters.project = event.target.value;
    saveState();
    render();
  });
  document.querySelector("#filterStart").addEventListener("change", (event) => {
    state.filters.startDate = event.target.value;
    saveState();
    render();
  });
  document.querySelector("#filterEnd").addEventListener("change", (event) => {
    state.filters.endDate = event.target.value;
    saveState();
    render();
  });
  document.querySelector("#clearDateRange").addEventListener("click", () => {
    state.filters.project = "All Projects";
    state.filters.startDate = "";
    state.filters.endDate = "";
    saveState();
    render();
  });
  document.querySelector("#resetData").addEventListener("click", () => {
    if (!confirm("Restore sample data? Current browser data will be replaced.")) return;
    state = structuredClone(sampleState);
    saveState();
    render();
  });
  document.querySelector("#saveSettings").addEventListener("click", () => {
    ["targetCpa", "minRoas", "minCtr", "minCvr", "reviewDays", "warningSpend"].forEach((key) => {
      state.settings[key] = numberValue(document.querySelector(`#${key}`).value);
    });
    saveState();
    render();
  });
  document.querySelector("#exportCsv").addEventListener("click", exportCsv);
}

function downloadImportTemplate() {
  const type = document.querySelector("#importType").value;
  const headers = importTemplates[type];
  const firstMetric = metricOptions()[0] || "CPA/CPL";
  const exampleRows = {
    campaigns: [[todayIso(), "Main Project", "act_123456789", "CMP-001", "Campaign Name", "Meta", "Feed", "India", "25-34", "Mobile", "Leads", 5000, firstMetric, 500, 420, 0, 0, 0, 0, 0, 0, 0]],
    changes: [["CHG-001", todayIso(), "Main Project", "act_123456789", "CMP-001", "Needs Action", "Image / Creative", "Changed image", "Low CPL", firstMetric, 500, 420, 0, 0, 0, "Performance", addDays(todayIso(), state.settings.reviewDays), "Monitor"]],
    projects: [["Main Project", "act_123456789"]],
    metrics: state.metrics.map((metric) => [metric.name, metric.direction || "higher"]),
  };
  download(`${type}-import-template.csv`, [headers, ...exampleRows[type]]);
}

async function importCsvFile(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  const type = document.querySelector("#importType").value;
  const status = document.querySelector("#importStatus");
  try {
    const rows = parseCsv(await file.text());
    if (rows.length < 2) {
      status.textContent = "Import file has no data rows.";
      return;
    }
    const headers = rows[0].map((header) => header.trim());
    const records = rows.slice(1).filter((row) => row.some((cell) => String(cell || "").trim())).map((row) => rowToObject(headers, row));
    if (type === "campaigns") importCampaigns(records);
    if (type === "changes") importChanges(records);
    if (type === "projects") importProjects(records);
    if (type === "metrics") importMetrics(records);
    normalizeState(state);
    saveState();
    render();
    status.textContent = `Imported ${records.length} ${type} row${records.length === 1 ? "" : "s"}.`;
  } catch (error) {
    status.textContent = `Import failed: ${error.message}`;
  } finally {
    event.target.value = "";
  }
}

function rowToObject(headers, row) {
  return headers.reduce((record, header, index) => {
    record[header] = row[index] ?? "";
    return record;
  }, {});
}

function importCampaigns(records) {
  records.forEach((record) => {
    upsertProject(record.Project, record["Ad Account ID"]);
    state.campaigns.push({
      date: record.Date || todayIso(),
      project: record.Project || "Main Project",
      id: record["Campaign ID"] || `CMP-${String(state.campaigns.length + 1).padStart(3, "0")}`,
      name: record.Name || "",
      platform: record.Platform || "Meta",
      placement: record.Placement || "",
      country: record.Country || "",
      age: record.Age || "",
      device: record.Device || "",
      objective: record.Objective || "Leads",
      status: "Active",
      metric: record.Metric || "CPA/CPL",
      before: numberValue(record["Before Value"]),
      after: numberValue(record["After Value"]),
      budget: numberValue(record.Budget),
      spend: numberValue(record.Spend),
      impressions: numberValue(record.Impressions),
      clicks: numberValue(record.Clicks),
      leads: numberValue(record.Leads),
      svc: numberValue(record.SVC),
      booked: numberValue(record.Booked),
      revenue: numberValue(record.Revenue),
    });
  });
}

function importChanges(records) {
  records.forEach((record) => {
    upsertProject(record.Project, record["Ad Account ID"]);
    state.changes.push({
      id: record["Change ID"] || `CHG-${String(state.changes.length + 1).padStart(3, "0")}`,
      date: record.Date || todayIso(),
      project: record.Project || "Main Project",
      campaignId: record["Campaign ID"] || campaignOptions()[0],
      campaignStatus: record["Campaign Status"] || "Active",
      type: record.Type || "Other",
      changed: record.Changed || "",
      reason: record.Reason || "",
      metric: record.Metric || "CPA/CPL",
      before: numberValue(record["Before Value"]),
      after: numberValue(record["After Value"]),
      leads: numberValue(record.Leads),
      svc: numberValue(record.SVC),
      booked: numberValue(record.Booked),
      owner: record.Owner || "Performance",
      followUp: record["Follow-up"] || addDays(record.Date || todayIso(), state.settings.reviewDays),
      nextAction: record["Next Action"] || "Monitor",
    });
  });
}

function importProjects(records) {
  records.forEach((record) => upsertProject(record.Project, record["Ad Account ID"]));
}

function importMetrics(records) {
  const imported = records
    .map((record) => ({
      name: record.Metric || "",
      direction: String(record["Improvement Direction"] || "higher").toLowerCase() === "lower" ? "lower" : "higher",
    }))
    .filter((metric) => metric.name);
  if (!imported.length) return;
  state.metrics = imported;
  const fallback = metricOptions()[0] || "CPA/CPL";
  state.campaigns.forEach((row) => {
    if (!state.metrics.some((metric) => metric.name === row.metric)) row.metric = fallback;
  });
  state.changes.forEach((row) => {
    if (!state.metrics.some((metric) => metric.name === row.metric)) row.metric = fallback;
  });
}

function upsertProject(name, adAccountId = "") {
  const projectName = name || "Main Project";
  const existing = state.projects.find((project) => project.name === projectName);
  if (existing) {
    if (adAccountId) existing.adAccountId = adAccountId;
    return;
  }
  state.projects.push({ name: projectName, adAccountId: adAccountId || "" });
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (char === '"' && quoted && next === '"') {
      cell += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(cell);
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  if (cell || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}

function exportCsv() {
  download("campaign-tracker.csv", [
    ["Date", "Project", "Ad Account ID", "Campaign ID", "Name", "Platform", "Placement", "Country", "Age", "Device", "Objective", "Status", "Last Edited", "Last Change", "Metric", "Before Value", "After Value", "Budget", "Spend", "Impressions", "Clicks", "Leads", "SVC", "Booked", "Revenue", "CTR", "CVR", "SVC %", "Booked %", "CPA/CPL", "ROAS", "Flag", "Performance"],
    ...state.campaigns.map((row) => {
      const calc = calcCampaign(row);
      return [row.date, row.project, adAccountForProject(row.project), row.id, row.name, row.platform, row.placement, row.country, row.age, row.device, row.objective, latestCampaignStatus(row.id, row.status), latestChangeDate(row.id), latestChangeText(row.id), row.metric || "CPA/CPL", row.before, row.after, row.budget, row.spend, row.impressions, row.clicks, calc.leads, calc.svc, calc.booked, row.revenue, percent(calc.ctr), percent(calc.cvr), percent(calc.svcRate), percent(calc.bookedRate), calc.cpa.toFixed(2), calc.roas.toFixed(2), calc.flag, calc.performance];
    }),
  ]);
  download("campaign-change-log.csv", [
    ["Change ID", "Date", "Project", "Ad Account ID", "Campaign ID", "Campaign Name", "Campaign Status", "Type", "Changed", "Reason", "Metric", "Before Value", "After Value", "Improved", "Leads", "SVC", "SVC %", "Booked", "Booked %", "Owner", "Follow-up", "Status", "Next Action"],
    ...state.changes.map((row) => {
      const funnel = calcChangeFunnel(row);
      const project = row.project || campaignProject(row.campaignId);
      return [row.id, row.date, project, adAccountForProject(project), row.campaignId, campaignName(row.campaignId), row.campaignStatus || latestCampaignStatus(row.campaignId), row.type, row.changed, row.reason, row.metric || "CPA/CPL", row.before, row.after, calcChange(row), funnel.leads, funnel.svc, percent(funnel.svcRate), funnel.booked, percent(funnel.bookedRate), row.owner, row.followUp, reviewStatus(row), row.nextAction];
    }),
  ]);
}

function download(filename, rows) {
  const csv = rows.map((row) => row.map(csvCell).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function csvCell(value) {
  const text = String(value ?? "");
  return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

bindEvents();
render();
